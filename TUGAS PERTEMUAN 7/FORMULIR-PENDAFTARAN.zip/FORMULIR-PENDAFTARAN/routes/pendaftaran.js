const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Render halaman formulir pertama
router.get('/1', (req, res) => {
    res.render('formulir-1', {
        nama: req.session.nama,
        nik: req.session.nik,
        jenis_kelamin: req.session.jenis_kelamin,
        tanggal_lahir: req.session.tanggal_lahir,
    });
});
// Proses simpan data pertama
router.post('/1', (req, res) => {
    const { nama, nik, jenis_kelamin, tanggal_lahir } = req.body;
    req.session.nama = nama;
    req.session.nik = nik;
    req.session.jenis_kelamin = jenis_kelamin;
    req.session.tanggal_lahir = tanggal_lahir;
    req.session.page = 2;
    res.redirect('/2');
});

// Render halaman formulir kedua
router.get('/2', (req, res) => {
    res.render('formulir-2', {
        telefon: req.session.telefon,
        email: req.session.email,
        alamat: req.session.alamat,
    });
});
// Proses simpan data kedua
router.post('/2', (req, res) => {
    const { telefon, email, alamat } = req.body;
    req.session.telefon = telefon;
    req.session.email = email;
    req.session.alamat = alamat;
    req.session.page = 3;
    res.redirect('/3');
});


// Render halaman formulir ketiga
router.get('/3', (req, res) => {
    res.render('formulir-3');
});

// Proses daftar 
router.post('/3', (req, res) => {

    const nama = req.session.nama;
    const nik = req.session.nik;
    const jenis_kelamin = req.session.jenis_kelamin;
    const tanggal_lahir = req.session.tanggal_lahir;
    const telefon = req.session.telefon;
    const email = req.session.email;
    const alamat = req.session.alamat;
    const { keterangan } = req.body;

    const query = "INSERT INTO hasil (nama, nik, jenis_kelamin, tanggal_lahir, telefon, email, alamat, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    db.query(query, [nama, nik, jenis_kelamin, tanggal_lahir, telefon, email, alamat, keterangan], (err, result) => {
        if (err) throw err;
        req.session.destroy();
        res.redirect(`/hasil/${result.insertId}`);
    });
});

router.get('/hasil/:id', (req, res) => {
    const query = 'SELECT * FROM hasil WHERE id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) throw err;
        res.render('hasil', { hasil: results[0] });
    });
});

module.exports = router;