const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const pendaftaranRoutes = require('./routes/pendaftaran');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
	secret: 'secret',
	resave: false,
	saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/', pendaftaranRoutes);

app.get('/', (req, res) => {
	if (req.session.page) {
		return res.redirect(`/${req.session.page}`);
	} else {
		return res.redirect('/1');
	}
});

// Menjalankan Server
app.listen(3000, () => {
	console.log('Server running on port 3000');
});